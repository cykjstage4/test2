package com.street.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @version 1.0
 * @author: OldStreetHong
 * @date: 2021/7/15 16:58
 * @desc:
 */
@RestController
public class HelloController {

    @ResponseBody
    @RequestMapping("hello/{name}")
    public String Hellow(@PathVariable String name) {
        System.out.println(name);
        return "hellow";
    }
}
