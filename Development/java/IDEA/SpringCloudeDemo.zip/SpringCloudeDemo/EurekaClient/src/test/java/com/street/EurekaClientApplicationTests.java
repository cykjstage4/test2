package com.street;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
