package com.street.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @version 1.0
 * @author: OldStreetHong
 * @date: 2021/7/15 16:11
 * @desc:
 */
@RestController
public class HellowController {

    @ResponseBody
    @RequestMapping("hello")
    public String Hellow() {
        return "hellow";
    }

    @ResponseBody
    @RequestMapping("")
    public String Hellow404() {
        return "404";
    }
}
